int algorithm1 (const int x[], int p, int q);
int algorithm2 (const int x[], int p, int q);
int algorithm3 (const int x[], int l, int u);
int algorithm4 (const int x[], int p, int q);

int max(int a, int b);
int max(int a, int b, int c);